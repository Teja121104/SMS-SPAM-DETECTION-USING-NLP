# SPAM_DETECTION-USING_NLP
It contains a collection of more than 5 thousand SMS phone messages and Detects Spam Messages using NATURAL LANGUAGE PROCESSING ..

___
# NLP (Natural Language Processing)

It basically consists of combining machine learning techniques with text, and using math and statistics to get that text in a format that the machine learning algorithms can understand!


___
Used these :>>
1 .Naive Bais Classifier 

2. After the counting, the term weighting and normalization can be done with [TF-IDF], using scikit-learn's TfidfTransformer.

3. Using Pipeline ( Eventually Pipeline is sufficient )
